package com.dev.instagramfocus

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 56, 48, 48)
        }

        val title = TextView(this).apply {
            text = "Instagram Focus Mode"
            textSize = 26f
            setPadding(0, 0, 0, 24)
        }

        val info = TextView(this).apply {
            text = """
                This companion service changes Instagram's UI behavior.

                • Keeps Instagram's bottom navigation visible.
                • Blocks Explore and Reels through an overlay.
                • Shows a motivational message when those tabs are tapped.
                • Hides post/reel grids on other people's profiles.
                • Monitors scroll events and can return to Direct Messages after a detected shared reel.
                • Story restrictions are handled by the accessibility service.

                Android does not provide a guaranteed 20 ms end-to-end response time. The service is optimized for low latency, but Instagram/Android scheduling can vary.
            """.trimIndent()
            textSize = 16f
            setPadding(0, 0, 0, 28)
        }

        val button = Button(this).apply {
            text = "Enable Accessibility Service"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val open = Button(this).apply {
            text = "Open Instagram"
            setOnClickListener {
                packageManager.getLaunchIntentForPackage("com.instagram.android")?.let {
                    startActivity(it)
                }
            }
        }

        root.addView(title)
        root.addView(info)
        root.addView(button)
        root.addView(open)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        // The service itself owns all Instagram overlays.
    }
}
